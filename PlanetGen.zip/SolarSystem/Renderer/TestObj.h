#pragma once
#include "RandableObj.h"


class TestObj : public RandableObj
{
	void update()
	{
		vertices = { -10,0,0,
					 0,0,10,
					 10,0,0 };

		for(int i = 0; i < vertices.size(); ++i)
		{
			int mod = i % 3;
			if(mod == 0)
			{
				vertices[i] += 0.999999f * cameraPos.x;
			}
			else if(mod == 1)
			{
				vertices[i] += 0.999999f * cameraPos.y;
			}
			else if(mod == 2)
			{
				vertices[i] += 0.999999f * cameraPos.z;
			}
		}
	}
};